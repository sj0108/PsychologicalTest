package com.iot.psychologicaltest;

public class ListItem {
 private int resId;
 private String title;


 public int getResId() {
  return resId;
 }

 public void setResId(int resId) {
  this.resId = resId;
 }

 public String getTitle() {
  return title;
 }

 public void setTitle(String title) {
  this.title = title;
 }

}
